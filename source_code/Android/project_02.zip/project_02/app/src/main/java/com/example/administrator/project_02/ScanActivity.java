package com.example.administrator.project_02;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by Administrator on 28/12/2017.
 */

public class ScanActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camera_main);
    }
    public void onClickNext1(View view) {
        Button btn_next1 = (Button) findViewById(R.id.godata1);
        Intent intent = new Intent(ScanActivity.this, DataQr.class);
        startActivity(intent);
    }
}
