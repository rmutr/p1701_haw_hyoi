package com.example.administrator.project_02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClickNext(View view) {
        Button btn_next = (Button) findViewById(R.id.gocamera);
        Intent intent = new Intent(MainActivity.this, ScanActivity.class);
        startActivity(intent);
    }
    public void onClickNext2(View view) {
        Button btn_next1 = (Button) findViewById(R.id.godata);
        Intent intent = new Intent(MainActivity.this, DataQr.class);
        startActivity(intent);
    }

}
