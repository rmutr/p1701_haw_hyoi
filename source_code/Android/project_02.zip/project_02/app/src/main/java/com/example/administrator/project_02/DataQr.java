package com.example.administrator.project_02;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by Administrator on 28/12/2017.
 */

public class DataQr extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dataqr_main);
    }
    public void onClickNext3(View view) {
        Button btn_next4 = (Button) findViewById(R.id.hht);
        Intent intent = new Intent(DataQr.this, MainActivity.class);
        startActivity(intent);
    }

}
